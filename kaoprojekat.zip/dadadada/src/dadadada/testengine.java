package dadadada;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import dadadada.Program.Ball;
import dadadada.Program.DrawPanel;

public class testengine{

	public static void main(String[] args) {
		
		Scanner kita= new Scanner(System.in);
    	int p=kita.nextInt();
    	int c=kita.nextInt();
    	int t=kita.nextInt();
    	Program1 program = new Program1();
    	program.cycles=c;
    	program.particles=p;
    	program.threads=t;
    	program.run();
    	kita.close();

	}

	static class pentaint{
		int xdif;
		int ydif;
		double angle;
		int hypotenuse;
		int charge;
	}


	static class Program1 {
		int cycles=10000;
		int particles=5;
		int threads;
	    private List<Ball> balls;

	    
	    int charger() {
	    	Random rand= new Random();
	    	return rand.nextInt(2);
	    }
	    
	    int masser() {
	    	Random rand= new Random();
	    	return rand.nextInt(10);
	    } 
	    
	    int directioner() {
	    	Random rand= new Random();
	    	return rand.nextInt(360);
	    }
	    int charg2e(int k){
	    	if(k==0)
	    		return -1;
	    	else 
	    		return 1;
	    }

	    public void run() {
	    	
	        balls = new ArrayList<>();
	        int k=charger();
	        int m=masser();
	        int d=directioner();
	        
	        if(threads==1) {
	        	 for (int i = 0; i <particles; i++) {
	 	            Ball ball = new Ball(
	 	                    (int) Math.floor(Math.random() * 800),
	 	                    (int) Math.floor(Math.random() * 600),
	 	                    m%5+5,
	 	                    k ,
	 	                    m,
	 	                    m,
	 	                    i,
	 	                    d
	 	            );
	 	            d=directioner();
	 	            k=charger();
	 	            m=masser();

	 	            balls.add(ball);
	 	        }

	 	        while (cycles>0) {
	 	            for (Ball b: balls) {
	 	            		b.update();
	 	                cycles--;
	 	            }
	 	        }
	        }        
	    }
	
	
	public class RunInterface implements Runnable   {
		
		int startin;
		int endin;
		
		public RunInterface(int st,int en) {
			startin=st;
			endin=en;
		}

		
		public void run() {
			
			
		}
		
	}
	
	 

	class Ball{
	        int posX, posY, size;
	        int acceleration;
	        int xacceleration;
	        int yacceleration;
	        int speed;
	        int charge;
	        int x;
	        int y;
	        int index;
	        int vx = 5;
	        int vy = 5;
			int direction;

	        public Ball(int posX, int posY, int mass,int charge1, int vx, int vy,int index,int direction) {
	            this.posX = posX;
	            this.posY = posY;
	            this.size = 25;
	            this.vx = vx;
	            this.vy = vy;
	            charge=charge1;
	            this.index=index;
	            this.direction=direction;
	        }

	        void update() {
	        	
	        	pentaint[] getted= getter(balls,this);
	        	int [] spec=accelerationcalculator(this,getted);	
	        	xacceleration=spec[0];
	        	yacceleration=spec[1];
	        	vx=vx+xacceleration;
	        	vy=vy+yacceleration;
	        	
	        	this.posX += vx;
	            this.posY += vy;
	            x=posX;
	            y=posY;

	        	

	            if (posX > 800 || posX < 0) {
	                vx *= -1;
	            }

	            if (posY > 600 || posY < 0) {
	                vy *= -1;
	            }

	            if (posX > 800) {
	                posX = 800;
	            }

	            if (posX < 0) {
	                posX = 0;
	            }

	            if (posY >600 ) {
	                posY =600 ;
	            }

	            if (posY < 0) {
	                posY = 0;
	            }
	            

	        }
        
	    	
	    	pentaint[] getter(List <Ball> balls,Ball cacko)
	    	{
	    		pentaint [] distances=new pentaint[balls.size()];
	    		int x=cacko.x;
	    		int y=cacko.y;
	    		int i=cacko.index;
	    		
	    		for(int j=0;j<balls.size();j++) {
	    			pentaint debil=new pentaint();
	    			if(i==j) {
	    				debil.angle=0;
	    				debil.xdif=0;
	    				debil.ydif=0;
	    				debil.hypotenuse=0;
	    				debil.charge=0;
	        			distances[j]=debil;

	    			}
	    			else {
	    			double angle=0;
	    			int xdif=Math.abs(x-balls.get(j).x);
	    			int ydif=Math.abs(y-balls.get(j).y);
	    			int hypotenuse=(int) Math.sqrt(((xdif)^2)+((ydif)^2));
	    			if(hypotenuse!=0)
	    				angle= Math.sin(ydif/hypotenuse);
	    			debil.angle=angle;
	    			debil.xdif=xdif;
	    			debil.ydif=ydif;
	    			debil.hypotenuse=hypotenuse;
	    			debil.charge=balls.get(j).charge;
	    			distances[j]=debil;
	    			}
	    		}
	    		return distances;	
	    	}
	    	
	    	int[] accelerationcalculator(Ball jaje, pentaint[] getted) {
	    		int[] q0= new int [2];
	    		double fx=0;
	    		double fy=0;
	    		for(int i=0;i<getted.length;i++)
	    		{
	    			double fc=(10.5/(getted[i].hypotenuse^2));
	    			if(getted[i].charge==jaje.charge)
	    				fc=fc*-1;
	    			if(getted[i].angle!=0)
	    			fx=fx+Math.cos(getted[i].angle)*fc;
	    			if(getted[i].angle!=60)
	    			fy=fy+Math.sin(getted[i].angle)*fc;
	    			
	    		}
			    q0[0]=(int) fx;
			    q0[1]=(int) fy;
	    	    return q0;
	    		
	    	}    	    	
	    } 

	}
	

}
