package dadadada;
import javax.swing.*;
import java.util.*;
import java.util.List;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Main {
	
    public static void main(String[] args) {
    	
    	
    	Scanner k= new Scanner(System.in);
    	//enter number of particles, i set cycles to inf for testing purposes
    	//also i made mass system instead of fixed, but i removed it because it seemed nonsensical for particles to have different masses
    	//i use thread sleep on drawing to be actually able to updates on screen, that will be removed on test versions and thread version
    	//physics used: modified columbs law for acceleration calculator.
    	//if particles get stuck in corners that that means other particles keep it pinned, increased bounce speed and it removed that issue, but 2x speed when bouncing is not realistic,
    	//so I kept it as it is, and we will call pinning particle in corner a feature, not a bug
    	//modify the constant on line 292 if you want to test validity of acceleration system;
    	//also i maybe used int where double should be used, but double sucks because it cant go over 16, so its more precise to round up than to have limiting factor.
    	//try resizing, you will see cool trick
    	int p=k.nextInt();
    	int c=Integer.MAX_VALUE;
    	Program program = new Program();
    	program.cycles=c;
    	program.particles=p;
    	program.run();
    	k.close();
 

    }
}

class pentaint{
	int xdif;
	int ydif;
	double angle;
	int hypotenuse;
	int charge;
}


class Program {
	int cycles=10000;
	int particles=5;
	int threads;
    private JFrame mainFrame;
    private DrawPanel drawPanel;
    private List<Ball> balls;

    private int windowWidth = 800;
    private int windowHeight = 600;
    private String windowLabel = "Bounce Program";
 
    
    Color kita(int k) {
    	if(k==1)
    		return Color.blue;
    	else 
    		return Color.red;
    }
    
    int charger() {
    	Random rand= new Random();
    	return rand.nextInt(2);
    }
    
    int masser() {
    	Random rand= new Random();
    	return rand.nextInt(10);
    } 
    
    int directioner() {
    	Random rand= new Random();
    	return rand.nextInt(360);
    }
    int charg2e(int k){
    	if(k==0)
    		return -1;
    	else 
    		return 1;
    }

    void run() {

        balls = new ArrayList<>();
        int k=charger();
        int m=masser();
        int d=directioner();

        /* Generate balls */
        for (int i = 0; i <particles; i++) {
            Ball ball = new Ball(
                    /* Random positions from 0 to windowWidth or windowHeight */
                    (int) Math.floor(Math.random() * windowWidth),
                    (int) Math.floor(Math.random() * windowHeight),
                    /* Random size from 10 to 30 */
                    m%5+5,
                    k ,
                    /* Random RGB colors*/
                    kita(k),
                    /* Random velocities from -5 to 5 */
                    m,
                    m,
                    i,
                    d
            );
            d=directioner();
            k=charger();
            m=masser();

            balls.add(ball);
        }

        /* Initialize program */
        mainFrame = new JFrame();
        drawPanel = new DrawPanel();
        drawPanel.setSize(windowWidth,windowHeight);
        mainFrame.getContentPane().add(drawPanel);
        mainFrame.setTitle(windowLabel);
        mainFrame.setSize(windowWidth, windowHeight);
        mainFrame.setVisible(true);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        while (cycles>0) {
            for (Ball b: balls) {
                b.update();
                cycles--;
            }
            /* Give Swing 10 milliseconds to see the update! */
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            mainFrame.repaint();
        }
    }

    class DrawPanel extends JPanel {
        @Override
        public void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);

            for (Ball b: balls) {
                b.draw(graphics);
            }

        }
    }

    class Ball {
        int posX, posY, size;
        Color color;
        int acceleration;
        int xacceleration;
        int yacceleration;
        int speed;
        int charge;
        int x;
        int y;
        int index;
        int vx = 5;
        int vy = 5;
		int direction;

        public Ball(int posX, int posY, int mass,int charge1, Color color, int vx, int vy,int index,int direction) {
            this.posX = posX;
            this.posY = posY;
            this.size = 25;
            this.color = color;
            this.vx = vx;
            this.vy = vy;
            charge=charge1;
            this.index=index;
            this.direction=direction;
        }

        void update() {
        	
        	pentaint[] getted= getter(balls,this);
        	int [] spec=accelerationcalculator(this,getted);	
        	xacceleration=spec[0];
        	yacceleration=spec[1];
        	vx=vx+xacceleration;
        	vy=vy+yacceleration;
        	
        	this.posX += vx;
            this.posY += vy;
            x=posX;
            y=posY;

        	

            if (posX > mainFrame.getWidth() || posX < 0) {
                vx *= -1;
            }

            if (posY > mainFrame.getHeight() || posY < 0) {
                vy *= -1;
            }

            if (posX > mainFrame.getWidth()) {
                posX = mainFrame.getWidth();
            }

            if (posX < 0) {
                posX = 1;
            }

            if (posY > mainFrame.getHeight()) {
                posY = mainFrame.getHeight();
            }

            if (posY < 0) {
                posY = 1;
            }
            
            
            

        }

        void draw(Graphics g) {
            g.setColor(color);
            g.fillOval(posX, posY, size, size);
        }
        
        
        
        int[] cartesiantranslator(int y,int x)
    	{
    		int q[] = new int[2];
    		q[1]= (int) (y-(windowHeight)/2);
    		q[0]= (int) (x-(windowWidth)/2);
    		return q;
    		
    	}
    	
    	int[] matrixtranslator(int y,int x)
    	{
    		int q[] = new int[2];
    		q[0]= (int) (y+(windowHeight)*2);
    		q[1]= (int) (x+(windowWidth)*2);
    		return q;
    		
    	}
    	
    	pentaint[] getter(List <Ball> balls,Ball cacko)
    	{
    		pentaint [] distances=new pentaint[balls.size()];
    		int x=cacko.x;
    		int y=cacko.y;
    		int i=cacko.index;
    		
    		for(int j=0;j<balls.size();j++) {
    			pentaint debil=new pentaint();
    			if(i==j) {
    				debil.angle=0;
    				debil.xdif=0;
    				debil.ydif=0;
    				debil.hypotenuse=0;
    				debil.charge=0;
        			distances[j]=debil;

    			}
    			else {
    			double angle=0;
    			int xdif=Math.abs(x-balls.get(j).x);
    			int ydif=Math.abs(y-balls.get(j).y);
    			int hypotenuse=(int) Math.sqrt(((xdif)^2)+((ydif)^2));
    			if(hypotenuse!=0)
    				angle= Math.sin(ydif/hypotenuse);
    			debil.angle=angle;
    			debil.xdif=xdif;
    			debil.ydif=ydif;
    			debil.hypotenuse=hypotenuse;
    			debil.charge=balls.get(j).charge;
    			distances[j]=debil;
    			}
    		}
    		return distances;	
    	}
    	
    	int[] accelerationcalculator(Ball jaje, pentaint[] getted) {
    		int[] q0= new int [2];
    		double fx=0;
    		double fy=0;
    		for(int i=0;i<getted.length;i++)
    		{
    			double fc=(10.5/(getted[i].hypotenuse^2));
    			if(getted[i].charge==jaje.charge)
    				fc=fc*-1;
    			if(getted[i].angle!=0)
    			fx=fx+Math.cos(getted[i].angle)*fc;
    			if(getted[i].angle!=60)
    			fy=fy+Math.sin(getted[i].angle)*fc;
    			
    		}
		    q0[0]=(int) fx;
		    q0[1]=(int) fy;
    	    return q0;
    		
    	}
    }
}
