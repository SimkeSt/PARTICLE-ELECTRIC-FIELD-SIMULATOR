package kaoProjekt;
import java.util.Scanner;
public class projektkao {

	public static void main(String[] args) {
		Scanner p=new Scanner(System.in);
		System.out.println("Insert number of elements ");
		int n=p.nextInt();
        int[] a2=new int[n];
		int[] a1=new int[n];
		System.out.println("Entries of array ");

		for(int i=0;i<n;i++) {
			
			a1[i]=p.nextInt();
	
	}
		System.out.println("Number of elements is "+n);
		int br=0;
		 for (int i=1;i<n;i++)  
		    { 
		        for (int j=0;j<i;j++)  { 
		        	
		        
		            if (a1[i]==a1[j] && i!=j ) br++; }

	}
		 int a5= n-br;
		 int a6=0;
		 int a7=0;
			System.out.println("Number of distinct elements is "+a5);
			for(int i=0;i<n;i++) {
				
				if(a1[i]%2==0) a6++;
				else a7++;
		}
			System.out.println("Number of even numbers "+a6);
			System.out.println("Number of odd numbers "+a7);
	        int [] fr = new int [n];  
			int visited = -1;  
	        for(int i = 0; i < n; i++){  
	            int count = 1;  
	            for(int j = i+1; j < n; j++){  
	                if(a1[i] == a1[j]){  
	                    count++;  
	                    fr[j]=visited;  
	                }  
	            }  
	            if(fr[i] != visited)  
	                fr[i] = count;  
	        }  
	        int maxo=0;
	        int maxn=0;
	        System.out.println(" Element | Frequency  | Percentage");   
	        for(int i = 0; i < fr.length; i++){  
	            if(fr[i] != visited)  { 
	            	if(fr[i]>maxo) {maxo=fr[i]; maxn=a1[i];}
	            	double perc=(fr[i]%n)*100/n;
	                System.out.println("        " + a1[i] + "       " + fr[i]+"     "+perc+"%");  
	        }   }
	        System.out.println(" Most occuring number is  "+maxn);  
	        
	        int maxim=0;
	    	for(int i=0;i<n;i++) {
	    		
	    		if(maxim<a1[i]) maxim=a1[i];
	    		}
	    	System.out.println(" biggest numb  "+maxim);
	    	
	    	int mini=1000000000;
	    	int krusveti=1000000000;
	    	for(int i=0;i<n;i++) {
	    		
	    		if(mini>a1[i]) mini=a1[i];

	    		
	    		}
	    	for(int i=0;i<n;i++)
	    	{
	    		if(krusveti>a1[i] && a1[i]!=mini) krusveti=a1[i];

	}
	    	System.out.println(" Second smallest  "+krusveti);

double pajs;
double sum=0;
	    	for(int i=0;i<n;i++)
	    	{
	    		sum=sum+a1[i];

	    }
	    	double SD=0;
	    	pajs=sum/n;
	    	System.out.println(" Average  "+pajs);
	    	for(int i=0;i<n;i++) {
	            SD += Math.pow(a1[i] - pajs, 2);
	        }
            System.out.println("Standard Deviation:"+Math.sqrt(SD/n));
            if (sum > Integer.MAX_VALUE) 
                throw new RuntimeException("Overflow occured");
            else if (sum < Integer.MIN_VALUE) {
                throw new RuntimeException("Underflow occured");}
                else
            System.out.println("Sum of all:"+sum);
     if(n%2==0) System.out.println("Median :"+(((a1[n/2])+(a1[n/2-1]))/2));
     else System.out.println("Median:"+a1[n/2]); //As median you mean middle of array right?
    int zabiru=0;
    int mal=0;
     for(int i=0;i<n;i++) {
     int k=a1[i]; 
     int rev=0;
     while(k != 0) {
         rev=rev*10;
         rev=rev+k%10;
         k=k/10;
     }
     if(rev==a1[i]) {zabiru++; if(mal<a1[i] && a1[i]<maxim) mal=a1[i]; }
     }
     System.out.println("Number of palidromes:"+zabiru);
     System.out.println("Largest palindrome that is also smaller than biggest number:"+mal);

	     
	for(int i=n-1;i>=0;i--) {
	     System.out.print(a1[i]+",");

}


			
}}
